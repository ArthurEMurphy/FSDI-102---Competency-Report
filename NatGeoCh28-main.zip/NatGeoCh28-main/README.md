# NatGeoCh28
Mock Nat Geo website for school project
